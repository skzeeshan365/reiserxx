﻿CKEDITOR.plugins.setLang( 'filerimage', 'it', {
	name: 'Inserisci immagine',
	edit: 'Modifica image',
	title: 'Proprietà immagine',
	titleBasic: 'Impostazioni di base',
	titleAdvanced: 'Impostazioni avanzate',
	noFileAlt: 'Nessun file selezionato',
	browse: 'Cerca',
	clear: 'Pulisci',
	url: 'URL',
	caption: 'Didascalia',
	useOriginal: 'Usa immagine originale',
	crop: 'Ritaglia',
	upscale: 'Ingrandisci',
	autoscale: 'Riscalatura automatica',
	thumbnailOption: 'Dimensioni predefinite',
	alt: 'Testo alternativo'
} );
